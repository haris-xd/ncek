<b></b> </br> <br>[![Github](https://img.shields.io/badge/Github-Mr.AKING-dimgray?style=flat-square&logo=github)](https://github.com/AKING110)<br> [![Facebook](https://img.shields.io/badge/Facebook-AKING-blue?style=flat-square&logo=facebook)](https://www.facebook.com/Imtiaz.Aking.07)<br> [![Whatsapp](https://img.shields.io/badge/Whatsapp-AKING-deepgreen?style=flat-square&logo=whatsapp)](https://wa.me/+923237528063)



<h1 align="center"> [MR.AKING]</h1>

<h2 align="center">  FB DUMPING TOOL FREE </h2>


## <b>installation</b>

🔰 _DUMP AUTO FILE_ 🔰

- `pkg update`
- `pkg upgrade`
- `pkg install git`
- `pkg install python`
- `pip install requests`
- `pip install mechanize`
- `rm -rf Dump`
- `git clone --depth=1 https://github.com/AKING110/Dump.git`
- `cd Dump`
- `python AKING.py`
     
 _RUN COMMANDS_
- `cd`
- `cd Dump` 
- `python AKING.py`

 ```Note : This Tools is Free Dumping Tool ```</br>
 [![Whatsapp](https://img.shields.io/badge/Whatsapp-AKING-deepgreen?style=flat-square&logo=whatsapp)](https://wa.me/+923237528063)
